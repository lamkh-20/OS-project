package OS;

/**
 *
 * @author njood
 */
public class PQNode {
    
    public PQNode next;
    public Program data;
    public int EMR;
    
    public PQNode(){
        data = null;
        next = null;
        EMR = 0;
    }
    
    public PQNode(Program e, int emr){
        data = e;
        this.EMR = emr;
        next = null;
    }
    
    //Setters & Getters
    
}
