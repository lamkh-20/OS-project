
package OS;

import java.io.*;

/**
 *
 * @author njood
 */
public class Files {
    

    public static void generateInput(){
        
        try{
        File input = new File("Jobs.txt");
        PrintWriter p = new PrintWriter(input);
        
        int id = 1;
        for(int i=0; i<100; i++){
            p.println(id++);
            p.println(Math.random() * (512 - 16) + 16);
            p.println(Math.random() * (256 - 16) + 16);
        }
        p.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public static LinkedPQ readFromFile() throws IOException{
        
        LinkedPQ jobs = new LinkedPQ();
        File programs = new File("jobs.txt");
        BufferedReader b;
        int JID, ECU, EMR;
        try{
        b = new BufferedReader(new FileReader(programs));
        }catch(FileNotFoundException e){
            return jobs;
        }
        try{
            for(int i=0; i<100; i++){
                JID = b.read(); ECU = b.read(); EMR = b.read();
                jobs.enqueue(new Program(JID, ECU, EMR), EMR);
            }
              
        }
        catch(Exception e){
        }
        b.close();
        
        return jobs;
    }
    
}
