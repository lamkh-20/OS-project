/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package OS;

/**
 *
 * @author njood
 */
public class HardDisk {
    
    private int STORAGE_SIZE = 2000000; // Unit = KB
    private LinkedPQ jobQueue;
    
    public HardDisk(){
        jobQueue = new LinkedPQ();
    }

    public LinkedPQ getJobQueue() {
        return jobQueue;
    }

    public void setJobQueue(LinkedPQ jobQueue) {
        this.jobQueue = jobQueue;
    }
    
    
}
