/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package OS;

/**
 *
 * @author njood
 */
public class IO_Device {
    
    int ioCount;
    private LinkedQueue IOQueue;
    
    public IO_Device(){
        ioCount = 0;
        IOQueue = new LinkedQueue(256);
    }

    public LinkedQueue getIOQueue() {
        return IOQueue;
    }
    
}
