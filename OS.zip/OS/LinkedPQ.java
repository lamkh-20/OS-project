package OS;

/**
 *
 * @author njood
 */
public class LinkedPQ {
    
    private int maxsize = 2000000;
    private int size;
    private PQNode head;
    private PQNode current;
    
    public LinkedPQ(){
        size = maxsize;
        head = null;
    }
    
    public int length(){
        return size;
    }
    public boolean full(){
    return size == 0;
    }
    
    public void getFirst(){
        current = head;
    }
    
    public void getNext(){
        current = current.next;
    }
    public boolean hasNext(){
        return current.next != null;
    }
    public Program enquiry(){
        return current.data;
    }
 
    
    public boolean enqueue(Program e, int emr){
        PQNode temp = new PQNode(e,emr);
        
        if(size == 0)return false;
        int tmp = size;
        tmp = tmp - emr;
        if(tmp < 0)
            return false;
        if(size == maxsize || emr > head.EMR){
            temp.next = head;
            head = temp;}
        else{
            PQNode post = head;
            PQNode pre = null;
            while (( post != null) && (post.EMR >= emr)){
                pre = post; 
                post= post.next;}

            pre.next = temp;
            temp.next = post;
        }
        size = size - emr; 
        return true;
    }
    
    public Program serve() {
        if(size == maxsize)
            return null;
        Program temp = head.data;
        size = size + head.EMR;
        head = head.next;
        
        return temp;
    }

    
}
