/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package OS;

/**
 *
 * @author njood
 */
public class RAM {
    
    private int STORAGE_SIZE = 192000; //Unit = KB
    private LinkedQueue readyQueue;
    
    public RAM(){
        readyQueue = new LinkedQueue(STORAGE_SIZE);
    }

    public LinkedQueue getReadyQueue() {
        return readyQueue;
    }

    public void setReadyQueue(LinkedQueue readyQueue) {
        this.readyQueue = readyQueue;
    }
    
}
