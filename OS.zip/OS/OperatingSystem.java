/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package OS;

import java.io.IOException;

/**
 *
 * @author njood
 */
public class OperatingSystem {

    private HardDisk disk;
    private RAM ram;
    private IO_Device IO;
    private double sizeofallprocess;
    private int interrupt;
    public double min, max, avg;
    public int jobCount = 0;
    
    
    
    public OperatingSystem(){
        disk = new HardDisk();
        ram = new RAM();
        IO = new IO_Device();
        interrupt = 0;
        sizeofallprocess = 0;
        min = max = 0;
        Files.generateInput();
     
    }
    
    
    public void JobScheduler(){
        try{
            LinkedPQ pq = Files.readFromFile();
            disk.setJobQueue(pq);
            pq.getFirst();
            double size = pq.enquiry().getEMR();
            max = min = size;
            sizeofallprocess += size;
            jobCount++;
            
            while(pq.hasNext()){
                jobCount++;
                pq.getNext();
               size = pq.enquiry().getEMR();
               if(max < size)
                   max = size;
               if(min > size)
                   min = size;
               sizeofallprocess += size;
            }
            
        }catch(IOException e){
            System.out.println(e.toString());
        }
    }
    
    public LinkedQueue ProcessScheduler(){
        boolean flag = true;
        Program temp;
        while(flag){
            temp = disk.getJobQueue().serve();
            if(temp == null)
                break;
            flag = ram.getReadyQueue().enqueue(temp);
                }
        return ram.getReadyQueue();
    }
    
    public boolean IORequest(){
		double io = Math.random(); 
		if(io <= 0.2) {
                        IO.ioCount++;
			return true;
		}
		return false;
	}
    
    public boolean terminatesN(){
		double tn = Math.random();
		if(tn <0.1) {
			return true;
		}
		return false;
	}                                                             
	public boolean terminatesAN(){
                double ta = Math.random();
		if(ta <0.05) {
			return true;
		}
		return false;
	}

    public IO_Device getIO() {
        return IO;
    }

    public void setIO(IO_Device IO) {
        this.IO = IO;
    }

    public HardDisk getDisk() {
        return disk;
    }

    public void setDisk(HardDisk disk) {
        this.disk = disk;
    }

    public RAM getRam() {
        return ram;
    }

    public void setRam(RAM ram) {
        this.ram = ram;
    }

    public void setSizeofallprocess(double sizeofallprocess) {
        this.sizeofallprocess = sizeofallprocess;
    }

    public double getSizeofallprocess() {
        return sizeofallprocess;
    }
        
    
}
