/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package OS;

/**
 *
 * @author njood
 */
public class CPU_OS {
    
    private CPU_OS() {
    }
    
    public static CPU_OS getInstance() {
        return CPU_OSHolder.INSTANCE;
    }
    
    private static class CPU_OSHolder {

        private static final CPU_OS INSTANCE = new CPU_OS();
    }
}
