package OS;

/**
 *
 * @author njood
 */
public class LinkedQueue {
    
    private Node head, tail, current;
    private int size;
    private int maxsize;
    private int count;
    
    
    public LinkedQueue(int max){
        maxsize = max;
        head = tail = null;
        size = max;
        count = 0;
    }
    
    public int length(){
        return size;
    }
    public boolean full(){
        return size == 0;
    }
    public boolean enqueue(Program e){
        
        Node temp = new Node(e);
        if(size == 0)
            return false;
        int tmp = size;
        tmp = tmp - e.getEMR();
        if(tmp < 0) return false;
        if(head == null)
            head = tail = temp;
            else
                tail = tail.next = temp;
        size = size - e.getECU(); 
        count++;
        return true;
        
    }
    public Program serve(){
        if(size == maxsize) return null;
        Program data = head.data;
        head = head.next;
        size = size + data.getECU();
        if(size == maxsize)
            tail = null;
        count--;
        return data;
    }
    public Program enquiry(){
        return current.data;
    }
    
}
