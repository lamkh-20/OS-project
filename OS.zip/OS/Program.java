/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package OS;

/**
 *
 * @author njood
 */
public class Program {
    
    String JID;
     int ECU;
    int EMR;
    int ioCount;
    public String state;
     int countCPU;
    boolean processed;
    int WT, IRT;

    
    public Program(int jid, int ecu, int emr){
        JID = jid+"";
        ECU = ecu;
        EMR = emr;
        countCPU = 0;
        ioCount = 0;
        WT = 0;
        IRT = 0;
        state = "new";
    }
    

    public int getCountCPU() {
        return countCPU;
    }
    

    public String getJID() {
        return JID;
    }

    public void setJID(String JID) {
        this.JID = JID;
    }

    public int getECU() {
        return ECU;
    }

    public void setECU(int ECU) {
        this.ECU = ECU;
    }

    public int getEMR() {
        return EMR;
    }

    public void setEMR(int EMR) {
        this.EMR = EMR;
    }

    public void setCountCPU(int countCPU) {
        this.countCPU = countCPU;
    }

    
    public int getIoCount() {
        return ioCount;
    }

    public void setIoCount(int ioCount) {
        this.ioCount = ioCount;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    
    
}
