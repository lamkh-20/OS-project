/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package OS;
import java.io.*;


/**
 *
 * @author njood
 */
public class CPU {
    
   public static void main(String[] args){
       
       OperatingSystem o = new OperatingSystem();
       o.JobScheduler();
       o.ProcessScheduler();
       int countNM = 0, countABN = 0;
       int initialcountbusy = 0, countbusy = 0;
       int countProcessed = 0;
       boolean checkedTer = false;
       
       
       		while ((o.ProcessScheduler().length() > 0)) {
			Program n;
			n = o.ProcessScheduler().serve();

			while(true){
				if (o.terminatesN()) {
					n.state = "Terminate Normally";
					countNM++;
					checkedTer = true;
					break;
				} else if (o.terminatesAN()) {
					n.state = "Terminate Abnormally";
					countABN++;
					checkedTer = true;
					break;
					}
                                  else if(!checkedTer){
						
                                        if (o.IORequest()) 
					{
					n.setIoCount(n.getIoCount()+1);
					n.state = "Busy";
					o.getIO().getIOQueue().enqueue(n);
					while(!o.IORequest()){							
						initialcountbusy++; // 3
							}
                                        
					n.WT+= initialcountbusy; //P1: 5  P2: 3
                                        
                                        countbusy+= initialcountbusy; //CPU: 8
                                        initialcountbusy = 0; //0
                                        o.getIO().getIOQueue().serve();
							
					
                                        }
                                        
                                        o.getRam().getReadyQueue().enqueue(n);
						
					}
		
                        
			 n.setCountCPU(n.getCountCPU()+1);

			} 
                        
		checkedTer=false;
		}// End While loop
       
   
                
   
   File o2 = new File("Results.txt");
		try{
			FileWriter fw = new FileWriter(o2);
			fw.write("The number of  jobs processed " + countProcessed +" Jobs");
			fw.write(System.getProperty("line.separator"));
			fw.write(System.getProperty("line.separator"));
			fw.write("The average program size of all jobs: " + o.getSizeofallprocess()/ o.jobCount  +"KB");
			fw.write(System.getProperty("line.separator"));
			fw.write(System.getProperty("line.separator"));
                        fw.write("The max program job size: " + o.max +"KB");
                        fw.write(System.getProperty("line.separator"));
			fw.write(System.getProperty("line.separator"));
                        fw.write("The min job size: " + o.min +"KB");
                        fw.write(System.getProperty("line.separator"));
			fw.write(System.getProperty("line.separator"));
			fw.write("The number of jobs that have completed their execution normally: " + countNM +" Jobs");
			fw.write(System.getProperty("line.separator"));
			fw.write(System.getProperty("line.separator"));
			fw.write("The number of jobs that have completed their execution abnormally: " + countABN+" Jobs");
			fw.write(System.getProperty("line.separator"));	
			fw.write(System.getProperty("line.separator"));
			
		
			fw.close();
		}catch(Exception ex){
			System.out.println("Some problem occures");
		}
    
                File o1 = new File("Program Details");
                
                            try{
				FileWriter fw = new FileWriter(o1);
				Program a;
				
				while(o.getRam().getReadyQueue().length() != 0){
					a= o.getRam().getReadyQueue().serve();
				fw.write("ID of Process is: " + a.JID);
				fw.write(System.getProperty("line.separator"));
				fw.write("The state is: " +a.state);
				fw.write(System.getProperty("line.separator"));
				fw.write("The program size: " +a.EMR);
				fw.write(System.getProperty("line.separator"));	
				fw.write("The CUT is " + a.ECU);
				fw.write(System.getProperty("line.separator"));
				fw.write("The IO Request Term is : " + a.IRT);
				fw.write(System.getProperty("line.separator"));	
				fw.write("The waiting term is : " + a.WT);
				fw.write(System.getProperty("line.separator"));	
				fw.write("Actual time is: " + a.data.getCountCPU());
				fw.write(System.getProperty("line.separator"));	
				fw.write(System.getProperty("line.separator"));
				fw.write("The average actual time and exepected time   is: " + (a.data.getCountCPU()+a.data.Exepected_Execution_time)/2);
				fw.write(System.getProperty("line.separator"));
				fw.write(System.getProperty("line.separator"));
				fw.write("====================================================================");
				fw.write(System.getProperty("line.separator"));	
				fw.write(System.getProperty("line.separator"));	

				}
				fw.close();
			
			}catch(Exception ex){
				System.out.println("Some problem occures");
			}
                
                
   }
}


































